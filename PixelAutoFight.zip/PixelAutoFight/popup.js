document.addEventListener('DOMContentLoaded', () => {
    const winCountElem = document.getElementById('winCount');
    const loseCountElem = document.getElementById('loseCount');
    const earningsElem = document.getElementById('earnings');
    const resetButton = document.getElementById('resetStats');
	const autoPlayAgainCheckbox = document.getElementById('autoPlayAgain');
	
	chrome.storage.sync.get(['autoPlayAgain'], (data) => {
        autoPlayAgainCheckbox.checked = data.autoPlayAgain || false;
    });

    autoPlayAgainCheckbox.addEventListener('change', () => {
        chrome.storage.sync.set({autoPlayAgain: autoPlayAgainCheckbox.checked});
    });

    chrome.storage.sync.get(['winCount', 'loseCount', 'earnings', 'selectedSuperKickIndex', 'selectedSuperDefenseIndex'], (data) => {
        winCountElem.textContent = data.winCount || 0;
        loseCountElem.textContent = data.loseCount || 0;
        earningsElem.textContent = data.earnings || 0;

        if (data.selectedSuperKickIndex !== undefined) {
            const selectedKick = document.querySelector(`.superKickOption[value="${data.selectedSuperKickIndex}"]`);
            selectedKick.classList.add('active');
        }

        if (data.selectedSuperDefenseIndex !== undefined) {
            const selectedDefense = document.querySelector(`.superDefenseOption[value="${data.selectedSuperDefenseIndex}"]`);
            selectedDefense.classList.add('active');
        }
    });

    resetButton.addEventListener('click', () => {
        chrome.storage.sync.set({ winCount: 0, loseCount: 0, earnings: 0 }, () => {
            winCountElem.textContent = 0;
            loseCountElem.textContent = 0;
            earningsElem.textContent = 0;
            document.querySelectorAll('.btn-option').forEach(button => button.classList.remove('active'));
        });
    });

    const handleCardSelection = (type, elem) => {
        const index = parseInt(elem.value, 10);
        const key = type === 'kick' ? 'selectedSuperKickIndex' : 'selectedSuperDefenseIndex';
        chrome.storage.sync.set({ [key]: index });
        chrome.runtime.sendMessage({ action: `clickSuper${type === 'kick' ? 'Kick' : 'Defense'}Card`, index: index });

        document.querySelectorAll(`.${type === 'kick' ? 'superKickOption' : 'superDefenseOption'}`).forEach(button => button.classList.remove('active'));
        elem.classList.add('active');
    };

    document.querySelectorAll('.superKickOption').forEach((elem) => {
        elem.addEventListener('click', () => handleCardSelection('kick', elem));
    });

    document.querySelectorAll('.superDefenseOption').forEach((elem) => {
        elem.addEventListener('click', () => handleCardSelection('defense', elem));
    });
	function updateStatsRealTime() {
		chrome.storage.sync.get(['winCount', 'loseCount', 'earnings'], (data) => {
			document.getElementById('winCount').textContent = data.winCount || 0;
			document.getElementById('loseCount').textContent = data.loseCount || 0;
			document.getElementById('earnings').textContent = data.earnings || 0;
		});
	}

	setInterval(updateStatsRealTime, 5000); 
});